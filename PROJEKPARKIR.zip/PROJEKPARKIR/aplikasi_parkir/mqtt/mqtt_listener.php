<?php

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../config/database.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

$config = require __DIR__ . '/../config/mqtt.php';

/* ================= MQTT INIT ================= */

$mqtt = new MqttClient(
    $config['broker'],
    $config['port'],
    $config['client_id']
);

/* ================= CONNECTION SETTINGS ================= */

$connectionSettings = (new ConnectionSettings)
    ->setUsername($config['username'])
    ->setPassword($config['password'])
    ->setUseTls(true);

/* ================= CONNECT MQTT ================= */

$mqtt->connect($connectionSettings, true);

/* ================= TOPIC ================= */

$topicEntry = $config['prefix'].'/'.$config['topic_rfid_entry'];
$topicExit  = $config['prefix'].'/'.$config['topic_rfid_exit'];

echo "MQTT RUNNING...\n";


/* =======================================================
   RFID ENTRY
======================================================= */

$mqtt->subscribe($topicEntry, function ($topic, $message) use ($mqtt, $conn, $config) {

    $uid = trim($message);

    echo "ENTRY RFID: ".$uid."\n";

    $cek = mysqli_query($conn,"
        SELECT * FROM parkir
        WHERE uid='$uid'
        AND status='masuk'
    ");

    if(mysqli_num_rows($cek) > 0){

        echo "UID sudah masuk\n";

        $mqtt->publish(
            $config['prefix'].'/'.$config['topic_oled'],
            'SUDAH MASUK',
            0
        );

        return;
    }

    mysqli_query($conn,"
        INSERT INTO parkir(uid,waktu_masuk,status)
        VALUES('$uid',NOW(),'masuk')
    ");

    echo "DATA ENTRY TERSIMPAN\n";

    $mqtt->publish(
        $config['prefix'].'/'.$config['topic_entry_servo'],
        'OPEN',
        0
    );

    $mqtt->publish(
        $config['prefix'].'/'.$config['topic_oled'],
        'ENTRY OPEN',
        0
    );

}, 0);



/* =======================================================
   RFID EXIT
======================================================= */

$mqtt->subscribe($topicExit, function ($topic, $message) use ($mqtt, $conn, $config) {

    $uid = trim($message);

    echo "EXIT RFID: ".$uid."\n";

    $cek = mysqli_query($conn,"
        SELECT * FROM parkir
        WHERE uid='$uid'
        AND status='masuk'
        ORDER BY id DESC
        LIMIT 1
    ");

    if(mysqli_num_rows($cek) == 0){

        echo "DATA TIDAK ADA\n";

        $mqtt->publish(
            $config['prefix'].'/'.$config['topic_oled'],
            'DATA TIDAK ADA',
            0
        );

        return;
    }

    $data = mysqli_fetch_assoc($cek);

    mysqli_query($conn,"
        UPDATE parkir SET
            waktu_keluar = NOW(),
            biaya = 5000,
            status = 'keluar'
        WHERE id='".$data['id']."'
    ");

    echo "DATA EXIT UPDATED\n";

    $mqtt->publish(
        $config['prefix'].'/'.$config['topic_exit_servo'],
        'OPEN',
        0
    );

    $mqtt->publish(
        $config['prefix'].'/'.$config['topic_oled'],
        'EXIT OPEN',
        0
    );

}, 0);



/* ================= LOOP ================= */

$mqtt->loop(true);