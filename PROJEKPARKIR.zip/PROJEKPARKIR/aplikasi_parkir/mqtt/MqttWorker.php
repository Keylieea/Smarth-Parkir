<?php
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../config/database.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

// ambil config MQTT
$config = require __DIR__ . '/mqtt_config.php';

$server   = $config['host'];
$port     = $config['port'];
$clientId = $config['client_id'];

$mqtt = new MqttClient($server, $port, $clientId);

$settings = (new ConnectionSettings)
    ->setKeepAliveInterval(60);

try {
    $mqtt->connect($settings, true);
    echo "✅ MQTT Connected...\n";

    $mqtt->subscribe('parkir/rfid', function ($topic, $message) use ($conn) {

        echo "\n====================\n";
        echo "📡 UID diterima: $message\n";

        $uid = mysqli_real_escape_string($conn, $message);

        // cek apakah user masih parkir
        $cek = mysqli_query($conn, "
            SELECT * FROM parkir 
            WHERE uid='$uid' AND waktu_keluar IS NULL
            ORDER BY id DESC LIMIT 1
        ");

        if (mysqli_num_rows($cek) > 0) {

            // 🚗 KELUAR
            $data = mysqli_fetch_assoc($cek);

            $masuk = strtotime($data['waktu_masuk']);
            $keluar = time();

            $durasi_jam = ceil(($keluar - $masuk) / 3600);
            $biaya = $durasi_jam * 2000;

            mysqli_query($conn, "
                UPDATE parkir 
                SET 
                    waktu_keluar = NOW(),
                    biaya = '$biaya',
                    status = 'keluar'
                WHERE id = {$data['id']}
            ");

            echo "🚗 KELUAR\n";
            echo "⏱ Durasi: $durasi_jam jam\n";
            echo "💰 Biaya: Rp $biaya\n";

        } else {

            // 🅿️ MASUK
            mysqli_query($conn, "
                INSERT INTO parkir (uid, waktu_masuk, status)
                VALUES ('$uid', NOW(), 'masuk')
            ");

            echo "🅿️ MASUK\n";
        }

    }, 0);

    $mqtt->loop(true);

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage();
}