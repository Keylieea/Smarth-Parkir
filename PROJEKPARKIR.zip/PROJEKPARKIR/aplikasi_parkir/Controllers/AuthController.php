<?php
session_start();
require "../config/database.php";
require "../models/User.php";

class AuthController
{
    public function login()
    {
        global $conn;
        $user = new User($conn);

        //  Validasi method
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: ../Views/auth/login.php");
            exit;
        }

        //  Validasi input ada
        if (!isset($_POST['username'], $_POST['password'])) {
            header("Location: ../Views/auth/login.php?error=invalid");
            exit;
        }

        //  Sanitasi input
        $username = trim(htmlspecialchars($_POST['username']));
        $password = trim($_POST['password']);

        //  Validasi input kosong
        if ($username === '' || $password === '') {
            header("Location: ../Views/auth/login.php?error=empty");
            exit;
        }

        // 🔐 Proses login
        $data = $user->login($username, $password);

        if ($data) {

    session_regenerate_id(true);

    $_SESSION['login'] = true;
    $_SESSION['user']  = $data['nama'];
    $_SESSION['role']  = $data['role'];

    //  Tambah pesan berhasil login
    $_SESSION['success'] = "Berhasil login, selamat datang ".$data['nama']."!";

    switch ($data['role']) {

        case 'owner':
            header("Location: ../Views/owner/dashboard.php");
            break;

        case 'admin':
            header("Location: ../Views/admin/dashboard.php");
            break;

        case 'petugas':
            header("Location: ../Views/petugas/monitor.php");
            break;
    }

    exit;
}
 else {
            header("Location: ../Views/auth/login.php?error=failed");
            exit;
        }
    }
}

$auth = new AuthController();
$auth->login();
