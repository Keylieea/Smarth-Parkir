<?php
class RfidController {

    public function masuk($uid){
        global $conn;

        mysqli_query($conn,"INSERT INTO parkir_masuk(uid) VALUES('$uid')");
        mysqli_query($conn,"INSERT INTO log_aktivitas(uid, aktivitas) VALUES('$uid','Kendaraan Masuk')");
    }

    public function keluar($uid){
        global $conn;

        mysqli_query($conn,"INSERT INTO parkir_keluar(uid) VALUES('$uid')");
        mysqli_query($conn,"INSERT INTO log_aktivitas(uid, aktivitas) VALUES('$uid','Kendaraan Keluar')");
    }
}
