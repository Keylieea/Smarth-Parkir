<?php
class TransaksiParkir {
    private $conn;

    public function __construct($db){
        $this->conn = $db;
    }

    public function getAll(){
        return $this->conn->query("SELECT * FROM transaksi ORDER BY id DESC");
    }
    public function countTransaksi(){
    $q = $this->conn->query("SELECT COUNT(*) total FROM transaksi");
    return $q->fetch_assoc()['total'];
}

public function pendapatanHariIni(){
    $q = $this->conn->query("SELECT SUM(fee) total FROM transaksi 
                             WHERE DATE(checkout_time)=CURDATE()");
    return $q->fetch_assoc()['total'] ?? 0;
}

public function pendapatanBulanIni(){
    $q = $this->conn->query("SELECT SUM(fee) total FROM transaksi 
                             WHERE MONTH(checkout_time)=MONTH(NOW())");
    return $q->fetch_assoc()['total'] ?? 0;
}

}
