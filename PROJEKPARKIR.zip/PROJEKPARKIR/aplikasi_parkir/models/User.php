<?php
class User {
    private $conn;

    public function __construct($conn){
        $this->conn = $conn;
    }

    public function login($username, $password){
        $p = md5($password);
        $q = mysqli_query($this->conn,"SELECT * FROM users WHERE username='$username' AND password='$p'");
        return mysqli_fetch_assoc($q);
    }
}
