<?php

return [

    'broker' => 'ebe5044e04d74868bc1606190afba340.s1.eu.hivemq.cloud',
    'port' => 8883,

    'username' => 'youdie',
    'password' => 'Yudislebew17',

    'client_id' => 'parkir-server-' . uniqid(),

    'prefix' => 'parking/yudi',

    // RFID INPUT
    'topic_rfid_entry' => 'entry/rfid',
    'topic_rfid_exit'  => 'exit/rfid',

    // OUTPUT KE ESP32
    'topic_oled' => 'oled',
    'topic_entry_servo' => 'entry/servo',
    'topic_exit_servo' => 'exit/servo'

];