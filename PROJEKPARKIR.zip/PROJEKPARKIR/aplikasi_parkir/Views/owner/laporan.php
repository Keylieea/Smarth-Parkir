<?php
session_start();
require "../../config/database.php";

// Proteksi login
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SESSION['role'] !== 'owner') {
    echo "Akses ditolak!";
    exit;
}

// Filter tanggal
$tgl1 = $_GET['tgl1'] ?? date('Y-m-01');
$tgl2 = $_GET['tgl2'] ?? date('Y-m-d');

// Query laporan
$q = mysqli_query($conn, "
SELECT *, TIMESTAMPDIFF(MINUTE,waktu_masuk,waktu_keluar) AS durasi 
FROM log_aktivitas 
WHERE DATE(waktu_keluar) BETWEEN '$tgl1' AND '$tgl2'
ORDER BY waktu_keluar DESC
");

// Total pendapatan
$total = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(biaya) AS total 
FROM log_aktivitas 
WHERE DATE(waktu_keluar) BETWEEN '$tgl1' AND '$tgl2'
"))['total'];

// Grafik per hari
$chart = mysqli_query($conn,"
SELECT DATE(waktu_keluar) AS tanggal, SUM(biaya) AS total 
FROM log_aktivitas 
WHERE DATE(waktu_keluar) BETWEEN '$tgl1' AND '$tgl2'
GROUP BY tanggal
");

$tanggal = [];
$income = [];

while($c=mysqli_fetch_assoc($chart)){
    $tanggal[] = $c['tanggal'];
    $income[] = $c['total'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Laporan Parkir</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
</li>
</ul>
<ul class="navbar-nav ml-auto">
<li class="nav-item">
<a href="../../logout.php" class="btn btn-danger btn-sm">Logout</a>
</li>
</ul>
</nav>

<!-- Sidebar -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
<a href="dashboard.php" class="brand-link">
<span class="brand-text font-weight-light ml-2">Owner Parkir</span>
</a>

<div class="sidebar">
<nav class="mt-2">
<ul class="nav nav-pills nav-sidebar flex-column">

<li class="nav-item">
<a href="dashboard.php" class="nav-link">
<i class="nav-icon fas fa-chart-line"></i>
<p>Dashboard</p>
</a>
</li>

<li class="nav-item">
<a href="laporan.php" class="nav-link active">
<i class="nav-icon fas fa-file-invoice"></i>
<p>Laporan Parkir</p>
</a>
</li>

</ul>
</nav>
</div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">

<div class="content-header">
<div class="container-fluid">
<h1 class="m-0">Laporan Parkir</h1>
</div>
</div>

<section class="content">
<div class="container-fluid">

<!-- FILTER -->
<div class="card">
<div class="card-header">
<h3 class="card-title">Filter Tanggal</h3>
</div>
<div class="card-body">
<form method="GET">
<div class="row">
<div class="col-md-4">
<label>Dari Tanggal</label>
<input type="date" name="tgl1" value="<?= $tgl1 ?>" class="form-control">
</div>
<div class="col-md-4">
<label>Sampai Tanggal</label>
<input type="date" name="tgl2" value="<?= $tgl2 ?>" class="form-control">
</div>
<div class="col-md-4 d-flex align-items-end">
<button class="btn btn-primary"><i class="fas fa-search"></i> Tampilkan</button>
<a href="export_excel.php?tgl1=<?= $tgl1 ?>&tgl2=<?= $tgl2 ?>" class="btn btn-success ml-2">
<i class="fas fa-file-excel"></i> Export Excel
</a>
</div>
</div>
</form>
</div>
</div>

<!-- TOTAL -->
<div class="small-box bg-success">
<div class="inner">
<h3>Rp<?= number_format($total ?? 0) ?></h3>
<p>Total Pendapatan</p>
</div>
<div class="icon"><i class="fas fa-money-bill-wave"></i></div>
</div>

<!-- GRAFIK -->
<div class="card">
<div class="card-header"><h3 class="card-title">Grafik Pendapatan Harian</h3></div>
<div class="card-body">
<canvas id="chartIncome"></canvas>
</div>
</div>

<!-- TABEL -->
<div class="card">
<div class="card-header"><h3 class="card-title">Data Transaksi Parkir</h3></div>
<div class="card-body table-responsive p-0">
<table class="table table-striped table-bordered">
<thead>
<tr>
<th>No</th>
<th>UID</th>
<th>Masuk</th>
<th>Keluar</th>
<th>Durasi (Menit)</th>
<th>Biaya</th>
</tr>
</thead>
<tbody>

<?php
$no=1;
while($d=mysqli_fetch_assoc($q)){
echo "<tr>
<td>$no</td>
<td>{$d['uid']}</td>
<td>{$d['waktu_masuk']}</td>
<td>{$d['waktu_keluar']}</td>
<td>{$d['durasi']}</td>
<td>Rp".number_format($d['biaya'])."</td>
</tr>";
$no++;
}
?>

</tbody>
</table>
</div>
</div>

</div>
</section>
</div>

</div>

<!-- Chart Script -->
<script>
const tanggal = <?= json_encode($tanggal); ?>;
const income = <?= json_encode($income); ?>;

new Chart(document.getElementById('chartIncome'), {
    type: 'bar',
    data: {
        labels: tanggal,
        datasets: [{
            label: 'Pendapatan',
            data: income,
            backgroundColor: '#28a745'
        }]
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

</body>
</html>
