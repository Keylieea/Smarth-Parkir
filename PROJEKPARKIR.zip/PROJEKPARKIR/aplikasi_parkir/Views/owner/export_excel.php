<?php
require "../../config/database.php";

$tgl1 = $_GET['tgl1'];
$tgl2 = $_GET['tgl2'];

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_parkir_$tgl1-$tgl2.xls");

echo "<table border='1'>
<tr>
<th>UID</th>
<th>Masuk</th>
<th>Keluar</th>
<th>Durasi (Menit)</th>
<th>Biaya</th>
</tr>";

$q = mysqli_query($conn,"
SELECT *, TIMESTAMPDIFF(MINUTE,waktu_masuk,waktu_keluar) AS durasi 
FROM log_aktivitas 
WHERE DATE(waktu_keluar) BETWEEN '$tgl1' AND '$tgl2'
");

while($d=mysqli_fetch_assoc($q)){
echo "<tr>
<td>{$d['uid']}</td>
<td>{$d['waktu_masuk']}</td>
<td>{$d['waktu_keluar']}</td>
<td>{$d['durasi']}</td>
<td>{$d['biaya']}</td>
</tr>";
}
echo "</table>";
