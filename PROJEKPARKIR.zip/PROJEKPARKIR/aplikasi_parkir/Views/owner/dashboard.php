<?php
session_start();
require "../../config/database.php";

// 🔐 Proteksi login
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SESSION['role'] !== 'owner') {
    echo "Akses ditolak!";
    exit;
}

// Statistik
$totalIncome   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(biaya) as total FROM log_aktivitas"))['total'];
$totalTransaksi = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM log_aktivitas"))['total'];
$avgIncome = ($totalIncome ?? 0) / ($totalTransaksi ?: 1);

// Grafik per bulan
$chart = mysqli_query($conn,"
SELECT DATE_FORMAT(waktu_keluar,'%Y-%m') as bulan, SUM(biaya) as total
FROM log_aktivitas
GROUP BY bulan ORDER BY bulan ASC
");

$bulan = [];
$dataIncome = [];

while($c=mysqli_fetch_assoc($chart)){
    $bulan[] = $c['bulan'];
    $dataIncome[] = $c['total'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Dashboard Owner</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- AdminLTE CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
</li>
</ul>

<ul class="navbar-nav ml-auto">
<li class="nav-item">
<a href="../../logout.php" class="btn btn-danger btn-sm">Logout</a>
</li>
</ul>
</nav>

<!-- Sidebar -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
<a href="#" class="brand-link">
<span class="brand-text font-weight-light ml-2">Owner Parkir</span>
</a>

<div class="sidebar">
<nav class="mt-2">
<ul class="nav nav-pills nav-sidebar flex-column">

<li class="nav-item">
<a href="dashboard.php" class="nav-link active">
<i class="nav-icon fas fa-chart-line"></i>
<p>Dashboard Owner</p>
</a>
</li>

<li class="nav-item">
<a href="laporan.php" class="nav-link">
<i class="nav-icon fas fa-file-invoice-dollar"></i>
<p>Laporan</p>
</a>
</li>

</ul>
</nav>
</div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">

<div class="content-header">
<div class="container-fluid">
<h1 class="m-0">Dashboard Owner</h1>
</div>
</div>

<section class="content">
<div class="container-fluid">

<!-- Statistik -->
<div class="row">

<div class="col-lg-4 col-6">
<div class="small-box bg-success">
<div class="inner">
<h3>Rp<?= number_format($totalIncome ?? 0) ?></h3>
<p>Total Pendapatan</p>
</div>
<div class="icon"><i class="fas fa-money-bill-wave"></i></div>
</div>
</div>

<div class="col-lg-4 col-6">
<div class="small-box bg-primary">
<div class="inner">
<h3><?= $totalTransaksi ?></h3>
<p>Total Transaksi</p>
</div>
<div class="icon"><i class="fas fa-receipt"></i></div>
</div>
</div>

<div class="col-lg-4 col-6">
<div class="small-box bg-warning">
<div class="inner">
<h3>Rp<?= number_format($avgIncome) ?></h3>
<p>Rata-rata / Transaksi</p>
</div>
<div class="icon"><i class="fas fa-chart-pie"></i></div>
</div>
</div>

</div>

<!-- GRAFIK  -->
<div class="row">

<!-- LINE CHART -->
<div class="col-md-6">
<div class="card">
<div class="card-header"><h3 class="card-title">Line Chart Pendapatan</h3></div>
<div class="card-body">
<canvas id="lineChart"></canvas>
</div>
</div>
</div>

<!-- BAR CHART -->
<div class="col-md-6">
<div class="card">
<div class="card-header"><h3 class="card-title">Bar Chart Pendapatan</h3></div>
<div class="card-body">
<canvas id="barChart"></canvas>
</div>
</div>
</div>

<!-- PIE CHART -->
<div class="col-md-6">
<div class="card">
<div class="card-header"><h3 class="card-title">Pie Chart Pendapatan</h3></div>
<div class="card-body">
<canvas id="pieChart"></canvas>
</div>
</div>
</div>

</div>

<!-- LOG TABLE -->
<div class="card">
<div class="card-header">
<h3 class="card-title">Log Aktivitas Terbaru</h3>
</div>
<div class="card-body table-responsive p-0">
<table class="table table-striped">
<thead>
<tr>
<th>UID</th>
<th>Masuk</th>
<th>Keluar</th>
<th>Biaya</th>
</tr>
</thead>
<tbody>

<?php
$q = mysqli_query($conn,"SELECT * FROM log_aktivitas ORDER BY id DESC LIMIT 20");
while($d=mysqli_fetch_assoc($q)){
echo "<tr>
<td>{$d['uid']}</td>
<td>{$d['waktu_masuk']}</td>
<td>{$d['waktu_keluar']}</td>
<td>Rp".number_format($d['biaya'])."</td>
</tr>";
}
?>

</tbody>
</table>
</div>
</div>

</div>
</section>
</div>

</div>

<!-- ================= CHART SCRIPT ================= -->
<script>
const bulan = <?= json_encode($bulan); ?>;
const incomeData = <?= json_encode($dataIncome); ?>;

// LINE CHART
new Chart(document.getElementById('lineChart'), {
    type: 'line',
    data: {
        labels: bulan,
        datasets: [{
            label: 'Pendapatan',
            data: incomeData,
            borderColor: '#007bff',
            backgroundColor: 'rgba(0,123,255,0.2)',
            fill: true,
            tension: 0.4
        }]
    }
});

// BAR CHART
new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: {
        labels: bulan,
        datasets: [{
            label: 'Pendapatan',
            data: incomeData,
            backgroundColor: '#28a745'
        }]
    }
});

// PIE CHART
new Chart(document.getElementById('pieChart'), {
    type: 'pie',
    data: {
        labels: bulan,
        datasets: [{
            data: incomeData,
            backgroundColor: [
                '#007bff','#28a745','#ffc107','#dc3545','#6610f2','#20c997','#fd7e14','#17a2b8'
            ]
        }]
    }
});
</script>

<!-- AdminLTE JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

</body>
</html>
