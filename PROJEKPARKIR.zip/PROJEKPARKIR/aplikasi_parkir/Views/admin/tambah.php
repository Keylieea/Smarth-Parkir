<?php
session_start();
require "../../config/database.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Tambah User</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
<div class="wrapper">

<div class="content-wrapper">
<section class="content d-flex align-items-center" style="min-height:90vh;">
<div class="container-fluid">

<div class="row justify-content-center w-100">
<div class="col-md-6">

<div class="card card-primary shadow-lg">
<div class="card-header text-center">
<h3 class="card-title">Tambah User</h3>
</div>

<form method="POST" action="simpan.php">
<div class="card-body">

<div class="form-group">
<label>Username</label>
<input type="text" name="username" class="form-control" required>
</div>

<div class="form-group">
<label>Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="form-group">
<label>Role</label>
<select name="role" class="form-control">
<option value="admin">Admin</option>
<option value="petugas">Petugas</option>
<option value="owner">Owner</option>
</select>
</div>


</div>

<div class="card-footer text-right">
<button type="submit" class="btn btn-primary">Simpan</button>
<a href="dashboard.php" class="btn btn-secondary">Kembali</a>
</div>

</form>
</div>

</div>
</div>
</div>
</section>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
