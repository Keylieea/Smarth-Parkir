<?php
require "../../config/database.php";
$id = $_GET['id'];

$d = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE id='$id'"));
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit User</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>

<body>
<div class="content-wrapper">
<section class="content d-flex align-items-center" style="min-height:90vh;">
<div class="container-fluid">

<div class="row justify-content-center w-100">
<div class="col-md-6">

<div class="card card-warning shadow-lg">
<div class="card-header text-center">
<h3>Edit User</h3>
</div>

<form method="POST" action="update.php">
<input type="hidden" name="id" value="<?= $d['id']; ?>">

<div class="card-body">

<div class="form-group">
<label>Username</label>
<input type="text" name="username" value="<?= $d['username']; ?>" class="form-control">
</div>

<div class="form-group">
<label>Password (Kosongkan jika tidak diganti)</label>
<input type="password" name="password" class="form-control">
</div>

<div class="form-group">
<label>Role</label>
<select name="role" class="form-control">
<option value="admin" <?= ($d['role']=='admin')?'selected':''; ?>>Admin</option>
<option value="petugas" <?= ($d['role']=='petugas')?'selected':''; ?>>Petugas</option>
<option value="owner" <?= ($d['role']=='owner')?'selected':''; ?>>Owner</option>
</select>

</div>

</div>

<div class="card-footer text-right">
<button type="submit" class="btn btn-warning">Update</button>
<a href="dashboard.php" class="btn btn-secondary">Kembali</a>
</div>

</form>
</div>

</div>
</div>
</div>
</section>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
