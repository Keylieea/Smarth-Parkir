<?php
require "../../config/database.php";

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role     = $_POST['role'];

mysqli_query($conn,"INSERT INTO users(username,password,role)
VALUES('$username','$password','$role')");

session_start();
$_SESSION['alert'] = "User berhasil ditambahkan!";

header("Location: dashboard.php");
