<?php
session_start();
require "../../config/database.php";

if(!isset($_SESSION['login']) || $_SESSION['role']!='admin'){
    die("Akses ditolak!");
}

$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM users WHERE id='$id'");

$_SESSION['alert'] = "User berhasil dihapus!";
header("Location: dashboard.php");
