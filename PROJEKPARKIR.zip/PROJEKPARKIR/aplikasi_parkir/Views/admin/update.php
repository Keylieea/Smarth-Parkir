<?php
require "../../config/database.php";

$id = $_POST['id'];
$username = $_POST['username'];
$role = $_POST['role'];

if($_POST['password'] != ""){
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    mysqli_query($conn,"UPDATE users SET username='$username', password='$pass', role='$role' WHERE id='$id'");
} else {
    mysqli_query($conn,"UPDATE users SET username='$username', role='$role' WHERE id='$id'");
}

session_start();
$_SESSION['alert'] = "User berhasil diupdate!";

header("Location: dashboard.php");
