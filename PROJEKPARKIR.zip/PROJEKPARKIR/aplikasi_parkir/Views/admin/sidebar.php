<aside class="main-sidebar">
<a href="#" class="brand-link">
<span class="brand-text">My Parkir</span>
</a>

<div class="sidebar">
<ul class="nav-sidebar">

<li>
<a href="index.php" class="nav-link">
<span> Dashboard</span>
</a>
</li>

<li>
<a href="kendaraan.php" class="nav-link">
<span> Data Kendaraan</span>
</a>
</li>

<li>
<a href="logout.php" class="nav-link logout">
<span> Logout</span>
</a>
</li>

</ul>
</div>
</aside>
