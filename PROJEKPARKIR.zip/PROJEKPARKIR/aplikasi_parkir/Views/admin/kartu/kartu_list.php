<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/PROJEKPARKIR/aplikasi_parkir/config/database.php';

if(isset($_POST['simpan'])){
$uid  = $_POST['uid'];
$nama = $_POST['nama'];
$plat = $_POST['plat'];

mysqli_query($conn,"
INSERT INTO kartu(uid,nama_pemilik,plat_nomor)
VALUES('$uid','$nama','$plat')
");

$_SESSION['alert']="Kartu berhasil ditambahkan";
header("Location: index.php");
exit;
}
?>
<form method="POST">
UID:<br>
<input type="text" name="uid" required><br><br>

Nama Pemilik:<br>
<input type="text" name="nama" required><br><br>

Plat Nomor:<br>
<input type="text" name="plat" required><br><br>

<button type="submit" name="simpan">Simpan</button>
</form>