<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/PROJEKPARKIR/aplikasi_parkir/config/database.php';

$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM kartu WHERE id=$id");

$_SESSION['alert']="Kartu berhasil dihapus";
header("Location: index.php");