<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/PROJEKPARKIR/aplikasi_parkir/config/database.php';

if(isset($_POST['simpan'])){
    $uid  = $_POST['uid'];
    $nama = $_POST['nama'];
    $plat = $_POST['plat'];

    mysqli_query($conn,"
        INSERT INTO kartu(uid,nama_pemilik,plat_nomor)
        VALUES('$uid','$nama','$plat')
    ");

    // Set session alert
    $_SESSION['alert'] = "Kartu berhasil ditambahkan";

    // Redirect langsung ke dashboard/index.php
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Tambah Kartu RFID</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="card card-primary shadow-sm">
        <div class="card-header">
          <h3 class="card-title"><i class="fas fa-id-card"></i> Form Tambah Kartu</h3>
        </div>
        <form method="POST">
          <div class="card-body">
            <div class="form-group">
              <label for="uid">UID</label>
              <input type="text" class="form-control" id="uid" name="uid" placeholder="Masukkan UID" required>
            </div>
            <div class="form-group">
              <label for="nama">Nama Pemilik</label>
              <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama Pemilik" required>
            </div>
            <div class="form-group">
              <label for="plat">Plat Nomor</label>
              <input type="text" class="form-control" id="plat" name="plat" placeholder="Masukkan Plat Nomor" required>
            </div>
          </div>
          <div class="card-footer">
            <button type="submit" name="simpan" class="btn btn-primary">
              <i class="fas fa-save"></i> Simpan
            </button>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
          </div>
        </form>
      </div>
    </div>
  </section>
</div>
</div>
</body>
</html>