<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/PROJEKPARKIR/aplikasi_parkir/config/database.php';

// Proteksi login
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}
if ($_SESSION['role'] !== 'admin') {
    echo "Akses ditolak!";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Data Kartu Kendaraan</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a href="../../../logout.php"class="btn btn-danger btn-sm">Logout</a>
    </li>
  </ul>
</nav>

<!-- Sidebar -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="../dashboard.php" class="brand-link">
    <span class="brand-text font-weight-light ml-2">Admin Parkir</span>
  </a>
  <div class="sidebar">
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
        <li class="nav-item">
          <a href="../dashboard.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>Data User</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="index.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">
            <i class="nav-icon fas fa-id-card"></i>
            <p>Data Kartu RFID</p>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">
  <div class="content-header">
    <div class="container-fluid">
      <h1 class="m-0">Data Kartu Kendaraan</h1>
    </div>
  </div>

  <section class="content">
    <div class="container-fluid">

      <div class="card shadow-sm">
        <div class="card-header">
          <h3 class="card-title"><i class="fas fa-id-card"></i> Daftar Kartu RFID</h3>
          <div class="card-tools">
            <a href="kartu_tambah.php" class="btn btn-primary btn-sm">
              <i class="fas fa-plus"></i> Tambah Kartu
            </a>
          </div>
        </div>

        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>UID</th>
                <th>Nama Pemilik</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $q = mysqli_query($conn,"SELECT * FROM kartu ORDER BY id DESC");
            while($d = mysqli_fetch_assoc($q)){
            ?>
              <tr>
                <td><?= $d['id']; ?></td>
                <td><?= $d['uid']; ?></td>
                <td><?= $d['nama_pemilik']; ?></td>
                <td>
                  <span class="badge badge-<?= $d['status']=='aktif'?'success':'danger'; ?>">
                    <?= $d['status']; ?>
                  </span>
                </td>
                <td>
                  <a href="kartu_edit.php?id=<?= $d['id']; ?>" class="btn btn-warning btn-sm">
                    <i class="fas fa-edit"></i>
                  </a>
                  <button onclick="hapusKartu(<?= $d['id']; ?>)" class="btn btn-danger btn-sm">
                    <i class="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </section>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function hapusKartu(id){
  Swal.fire({
    title: 'Hapus kartu?',
    text: "Data tidak bisa dikembalikan!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Ya, hapus!'
  }).then((result)=>{
    if(result.isConfirmed){
      window.location="kartu_hapus.php?id="+id;
    }
  });
}
</script>

<!-- SweetAlert2 Toast untuk alert success -->
<?php if(isset($_SESSION['alert'])): ?>
<script>
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 2500,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
});
Toast.fire({
  icon: 'success',
  title: '<?= $_SESSION["alert"]; ?>'
});
<?php unset($_SESSION['alert']); ?>
</script>
<?php endif; ?>

</body>
</html>