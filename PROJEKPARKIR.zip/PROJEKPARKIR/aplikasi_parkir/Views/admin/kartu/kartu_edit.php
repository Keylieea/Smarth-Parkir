<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/PROJEKPARKIR/aplikasi_parkir/config/database.php';

$id = $_GET['id'];
$d = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM kartu WHERE id=$id"));

if(isset($_POST['update'])){
$uid  = $_POST['uid'];
$nama = $_POST['nama'];
$plat = $_POST['plat'];
$status = $_POST['status'];

mysqli_query($conn,"
UPDATE kartu SET uid='$uid', nama_pemilik='$nama', plat_nomor='$plat', status='$status'
WHERE id=$id
");

$_SESSION['alert']="Kartu berhasil diupdate";
header("Location: index.php");
exit;
}
?>

<form method="POST">
<h3>Edit Kartu RFID</h3>
UID:<br>
<input type="text" name="uid" value="<?= $d['uid']; ?>"><br><br>

Nama Pemilik:<br>
<input type="text" name="nama" value="<?= $d['nama_pemilik']; ?>"><br><br>

Plat Nomor:<br>
<input type="text" name="plat" value="<?= $d['plat_nomor']; ?>"><br><br>

Status:<br>
<select name="status">
<option value="aktif" <?= $d['status']=='aktif'?'selected':''; ?>>Aktif</option>
<option value="blokir" <?= $d['status']=='blokir'?'selected':''; ?>>Blokir</option>
</select><br><br>

<button type="submit" name="update">Update</button>
</form>