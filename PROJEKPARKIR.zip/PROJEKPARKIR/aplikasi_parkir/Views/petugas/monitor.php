<?php
session_start();
include '../../config/database.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SESSION['role'] !== 'petugas') {
    echo "<h3 style='text-align:center;margin-top:50px'>Akses ditolak</h3>";
    exit;
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Parkir</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
/* BODY ADMIN LTE  */
body{
    background:#f4f6f9;
    font-family: "Source Sans Pro", system-ui, sans-serif;
}

/* NAVBAR ADMINLTE  */
.navbar-custom{
    background:#343a40;
    border-bottom: 1px solid #4b545c;
}

.navbar-brand{
    font-size:1.1rem;
    font-weight:600;
}

/* CARD ADMINLTE  */
.custom-card{
    background:#fff;
    border:1px solid #dee2e6;
    border-radius: .25rem;
    box-shadow: 0 0 1px rgba(0,0,0,.125), 0 1px 3px rgba(0,0,0,.2);
}

/* HEADER ADMINLTE STYLE */
.card-header-custom{
    background:#f8f9fa;
    border-bottom:1px solid #dee2e6;
    font-weight:600;
    color:#343a40;
}

/* =TABLE ADMINLTE  */
.table{
    font-size:0.95rem;
}
.table thead{
    background:#f8f9fa;
    color:#495057;
}
.table tbody tr:hover{
    background:#f1f3f5;
}

/* BADGE  */
.badge-uid{
    background:#343a40;
    padding:4px 8px;
    border-radius:4px;
    color:white;
    font-size:0.85rem;
}

.badge-biaya{
    background:#17a2b8;
    padding:4px 8px;
    border-radius:4px;
    color:white;
    font-size:0.85rem;
}

/* BUTTON ADMINLTE  */
.btn-custom{
    background:#007bff;
    border-color:#007bff;
    color:white;
    border-radius:.2rem;
    font-size:0.85rem;
}

.btn-custom:hover{
    background:#0069d9;
}

.btn-outline-custom{
    border:1px solid #6c757d;
    color:#6c757d;
    border-radius:.2rem;
    font-size:0.85rem;
}

.btn-outline-custom:hover{
    background:#6c757d;
    color:white;
}

/* LOGOUT BUTTON */
.navbar .btn-light{
    font-size:0.85rem;
    border-radius:20px;
}


</style>

</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">
      <i class="bi bi-car-front-fill"></i> Dashboard Parkir
    </a>
    <div class="ms-auto">
      <a href="../../logout.php" class="btn btn-light btn-sm rounded-pill px-3">
        Logout
      </a>
    </div>
  </div>
</nav>

<div class="container py-4">

<!-- SEDANG PARKIR -->
<div class="card custom-card mb-4">
<div class="card-header card-header-custom">
<i class="bi bi-clock-history"></i> Sedang Parkir
</div>
<div class="card-body table-responsive">
<table class="table align-middle">
<thead>
<tr>
<th>No</th>
<th>UID</th>
<th>Waktu Masuk</th>
</tr>
</thead>
<tbody>

<?php
$q = mysqli_query($conn,"SELECT * FROM parkir WHERE status='masuk'");
$no = 1;
if(mysqli_num_rows($q) > 0){
while($d=mysqli_fetch_assoc($q)){
echo "<tr>
<td>$no</td>
<td><span class='badge badge-uid'>{$d['uid']}</span></td>
<td>{$d['waktu_masuk']}</td>
</tr>";
$no++;
}
}else{
echo "<tr><td colspan='3' class='text-center text-muted'>Tidak ada kendaraan</td></tr>";
}
?>

</tbody>
</table>
</div>
</div>

<!-- BELUM BAYAR = -->
<div class="card custom-card mb-4">
<div class="card-header card-header-custom">
<i class="bi bi-exclamation-circle"></i> Belum Bayar
</div>
<div class="card-body table-responsive">
<table class="table align-middle">
<thead>
<tr>
<th>No</th>
<th>UID</th>
<th>Waktu Keluar</th>
<th>Biaya</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>

<?php
$q = mysqli_query($conn,"SELECT * FROM parkir WHERE status='keluar'");
$no = 1;
if(mysqli_num_rows($q) > 0){
while($d=mysqli_fetch_assoc($q)){
echo "<tr>
<td>$no</td>
<td><span class='badge badge-uid'>{$d['uid']}</span></td>
<td>{$d['waktu_keluar']}</td>
<td><span class='badge badge-biaya'>Rp".number_format($d['biaya'])."</span></td>
<td>
<a href='buka_palang.php?uid={$d['uid']}' 
class='btn btn-custom btn-sm'>
Buka
</a>
</td>
</tr>";
$no++;
}
}else{
echo "<tr><td colspan='5' class='text-center text-muted'>Tidak ada transaksi</td></tr>";
}
?>

</tbody>
</table>
</div>
</div>

<!--  LOG AKTIVITAS -->
<div class="card custom-card">
<div class="card-header card-header-custom">
<i class="bi bi-journal-text"></i> Log Aktivitas
</div>
<div class="card-body table-responsive">
<table class="table align-middle">
<thead>
<tr>
<th>No</th>
<th>UID</th>
<th>Masuk</th>
<th>Keluar</th>
<th>Durasi</th>
<th>Biaya</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>

<?php
$q = mysqli_query($conn,"SELECT * FROM log_aktivitas ORDER BY id DESC LIMIT 50");
$no = 1;
if(mysqli_num_rows($q) > 0){
while($d=mysqli_fetch_assoc($q)){

$durasi = "1 Jam";
$biaya  = 5000;

if(!empty($d['waktu_masuk']) && !empty($d['waktu_keluar'])){

    $masuk  = new DateTime($d['waktu_masuk']);
    $keluar = new DateTime($d['waktu_keluar']);

    if($keluar > $masuk){

        $selisih_detik = $keluar->getTimestamp() - $masuk->getTimestamp();
        $jam = ceil($selisih_detik / 3600);

        if($jam < 1){
            $jam = 1;
        }

        $durasi = $jam . " Jam";
        $biaya  = $jam * 5000; 
    }
}


echo "<tr>
<td>$no</td>
<td><span class='badge badge-uid'>{$d['uid']}</span></td>
<td>{$d['waktu_masuk']}</td>
<td>{$d['waktu_keluar']}</td>
<td>$durasi</td>
<td><span class='badge badge-biaya'>Rp".number_format($biaya)."</span></td>
<td>
<button class='btn btn-outline-custom btn-sm'
onclick=\"cetakStruk(
'{$d['uid']}',
'{$d['waktu_masuk']}',
'{$d['waktu_keluar']}',
'$durasi',
'$biaya'
)\">
<i class='bi bi-printer'></i>
</button>
</td>
</tr>";

$no++;
}
}else{
echo "<tr><td colspan='7' class='text-center text-muted'>Belum ada log</td></tr>";
}
?>

</tbody>
</table>
</div>
</div>

</div>

<script>
function cetakStruk(uid, masuk, keluar, durasi, biaya){

let isi = `
<!DOCTYPE html>
<html>
<head>
<title>Struk Parkir</title>
<style>
    body{
        font-family: monospace;
        width:300px;
        margin:0 auto;
        padding:10px;
    }
    h3{
        text-align:center;
        margin:5px 0;
    }
    hr{
        border:0;
        border-top:1px dashed #000;
        margin:8px 0;
    }
    .row{
        display:flex;
        justify-content:space-between;
        margin:3px 0;
    }
    .center{
        text-align:center;
        margin-top:10px;
        font-size:12px;
    }
</style>
</head>
<body onload="window.print(); setTimeout(() => window.close(), 500);">

<h3>STRUK PARKIR</h3>
<hr>

<div class="row">
    <span>UID</span>
    <span>${uid}</span>
</div>

<div class="row">
    <span>Masuk</span>
    <span>${masuk}</span>
</div>

<div class="row">
    <span>Keluar</span>
    <span>${keluar}</span>
</div>

<div class="row">
    <span>Durasi</span>
    <span>${durasi}</span>
</div>

<hr>

<div class="row" style="font-weight:bold;">
    <span>Total</span>
    <span>Rp ${parseInt(biaya).toLocaleString()}</span>
</div>

<hr>

<div class="center">
    Terima Kasih<br>
    Simpan Struk Ini
</div>

</body>
</html>
`;

let win = window.open('', 'PRINT', 'width=400,height=600');
win.document.write(isi);
win.document.close();
}
</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if(isset($_SESSION['success'])): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Login Berhasil',
    text: '<?= $_SESSION['success']; ?>',
    timer: 1800,
    showConfirmButton: false
});
</script>

<?php unset($_SESSION['success']); endif; ?>
<script src="https://unpkg.com/mqtt/dist/mqtt.min.js"></script>

<script>
const client = mqtt.connect('wss://broker.hivemq.com:8884/mqtt', {
    clientId: 'monitor-' + Math.random().toString(16).substr(2,8)
});

client.on('connect', function () {
    console.log("MQTT Connected");

    // subscribe semua event
    client.subscribe("parkir/smart/#");
});

client.on('message', function (topic, message) {

    console.log("Update dari MQTT:", topic, message.toString());

    // reload data dashboard
    setTimeout(() => {
        location.reload();
    }, 500);

});
</script>
</html>
