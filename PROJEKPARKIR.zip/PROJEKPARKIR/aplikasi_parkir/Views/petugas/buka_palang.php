<?php

session_start();

include '../../config/database.php';
require __DIR__ . '/../../vendor/autoload.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

$config = require __DIR__ . '/../../config/mqtt.php';

$uid = $_GET['uid'];


/* ================= AMBIL DATA PARKIR ================= */

$q = mysqli_query($conn,"
    SELECT * FROM parkir
    WHERE uid='$uid'
    AND status='keluar'
    ORDER BY id DESC
    LIMIT 1
");

$data = mysqli_fetch_assoc($q);

if(!$data){
    $_SESSION['error'] = "Data tidak ditemukan!";
    header("Location: monitor.php");
    exit;
}


/* ================= PINDAH KE LOG ================= */

mysqli_query($conn,"
    INSERT INTO log_aktivitas(
        uid,
        waktu_masuk,
        waktu_keluar,
        biaya
    )
    VALUES(
        '".$data['uid']."',
        '".$data['waktu_masuk']."',
        '".$data['waktu_keluar']."',
        '".$data['biaya']."'
    )
");


/* ================= HAPUS DARI PARKIR ================= */

mysqli_query($conn,"
    DELETE FROM parkir
    WHERE id='".$data['id']."'
");


/* ================= MQTT BUKA PALANG ================= */

$mqtt = new MqttClient(
    $config['broker'],
    $config['port'],
    'web-' . uniqid()
);

$connectionSettings = (new ConnectionSettings)
    ->setUsername($config['username'])
    ->setPassword($config['password'])
    ->setUseTls(true);

$mqtt->connect($connectionSettings, true);


/* buka servo keluar */
$mqtt->publish(
    $config['prefix'].'/'.$config['topic_exit_servo'],
    'OPEN',
    1
);


/* tampil oled pembayaran berhasil */
$mqtt->publish(
    $config['prefix'].'/'.$config['topic_oled'],
    'PEMBAYARAN BERHASIL',
    1
);

usleep(500000);

$mqtt->disconnect();


/* ================= ALERT SUCCESS ================= */

$_SESSION['success'] = "Pembayaran telah dikonfirmasi!";


/* ================= REDIRECT ================= */

header("Location: monitor.php");
exit;