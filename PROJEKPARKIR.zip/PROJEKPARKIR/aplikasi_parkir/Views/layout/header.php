<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Parkir</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<header>
    <div class="nav">
        <strong>PARKIR</strong>
        <div>
            <a href="../Controllers/ParkirController.php">Transaksi</a>
            <a href="../Controllers/AuthController.php?aksi=logout.php">Logout</a>
        </div>
    </div>
</header>

<div class="container">
