<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login Sistem Parkir</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
body{
    height:100vh;
    margin:0;
    background:#f3f4f6;
    font-family: 'Segoe UI', sans-serif;
}

/* ===== HEADER ===== */
.navbar-custom{
    background: linear-gradient(90deg, #111827, #1f2937);
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}
.logo{
    width:32px;
    height:32px;
}
.brand-name{
    color:white;
    font-weight:600;
    font-size:1.2rem;
    letter-spacing:0.5px;
}

/* ===== LEFT SIDE ===== */
.bg-left{
    background: linear-gradient(135deg, #0f172a, #1e293b, #111827);
    display:flex;
    align-items:center;
    position:relative;
    padding-left:80px;
    overflow:hidden;
}
.bg-left::after{
    content:"";
    position:absolute;
    width:100%;
    height:100%;
    background: radial-gradient(circle at left, rgba(239,68,68,0.25), transparent 60%);
}

/* TEXT */
.brand-text{
    color:white;
    z-index:2;
}
.brand-text h1{
    font-size:3.5rem;
    font-weight:800;
    letter-spacing:-1px;
}
.brand-text span{
    color:#ef4444;
}
.brand-text p{
    opacity:0.85;
}

/* IMAGE */
.motor-img{
    position:absolute;
    right:40px;
    bottom:-40px;
    width:420px;
    opacity:0.6;
}

/* ===== LOGIN BOX ===== */
.login-box{
    background: rgba(255,255,255,0.95);
    border-radius:20px;
    padding:40px;
    width:75%;
    box-shadow: 
        0 10px 30px rgba(0,0,0,0.15),
        0 0 0 1px rgba(255,255,255,0.2) inset;
    animation: fadeUp .7s ease;
    transition: all 0.3s ease;
}
.login-box:hover{
    transform: translateY(-3px);
}

/* ANIMATION */
@keyframes fadeUp{
    from{opacity:0; transform:translateY(30px);}
    to{opacity:1; transform:translateY(0);}
}

/* INPUT */
.input-group{
    border-radius:12px;
    overflow:hidden;
}
.input-group-text{
    background:#f1f5f9;
    border:none;
}
.form-control{
    border:none;
    background:#f8fafc;
}
.form-control:focus{
    box-shadow:none;
    background:white;
}

/* BUTTON */
.btn-primary{
    background: linear-gradient(135deg,#2563eb,#3b82f6);
    border:none;
    border-radius:10px;
    font-weight:600;
    letter-spacing:0.5px;
    transition: all 0.3s ease;
}
.btn-primary:hover{
    transform: translateY(-1px);
    box-shadow:0 5px 15px rgba(37,99,235,0.4);
}

/* LOGO LOGIN */
.login-logo{
    width:55px;
    margin-bottom:10px;
}
</style>

</head>
<body>

<!-- ===== HEADER ===== -->
<nav class="navbar navbar-dark px-4 navbar-custom">
    <div class="d-flex align-items-center gap-2">
        <img src="../../assets/img/logo.png" class="logo">
        <span class="brand-name">MyParkir</span>
    </div>
</nav>

<div class="container-fluid h-100">
<div class="row h-100">

<!-- LEFT -->
<div class="col-md-7 d-none d-md-block bg-left">

    <img src="../../assets/img/My-removebg-preview.png" class="motor-img">

    <div class="brand-text">
        <h1>Smart <span>Parking</span></h1>
        <p class="mt-3">Solusi parkir otomatis, cepat, dan efisien</p>
    </div>

</div>

<!-- RIGHT -->
<div class="col-md-5 d-flex align-items-center justify-content-center">

    <div class="login-box text-center">

        <img src="../../assets/img/logo.png" class="login-logo">

        <h4 class="fw-bold mb-4">Login Sistem Parkir</h4>

        <form method="POST" action="../../controllers/AuthController.php">

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="bi bi-person"></i></span>
                <input type="text" name="username" class="form-control form-control-lg" placeholder="Username" required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100">
                <i class="bi bi-box-arrow-in-right"></i> Login
            </button>

        </form>

        <p class="text-muted mt-4 small">
            © 2026 MyParkir System
        </p>

    </div>

</div>

</div>
</div>

</body>
</html>

<?php if (isset($_GET['error'])): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {

    <?php if ($_GET['error'] === 'empty'): ?>
        Swal.fire({
            icon: 'warning',
            title: 'Oops!',
            text: 'Username dan password wajib diisi',
            confirmButtonColor: '#3085d6'
        });

    <?php elseif ($_GET['error'] === 'failed'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Login Gagal',
            text: 'Username atau password salah',
            confirmButtonColor: '#d33'
        });

    <?php elseif ($_GET['error'] === 'invalid'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Request Tidak Valid',
            text: 'Silakan login ulang',
            confirmButtonColor: '#d33'
        });
    <?php endif; ?>

});
</script>
<?php endif; ?>